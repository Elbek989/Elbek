a = "file2"
b = "file.txt"
c = "file3"

with open(a, 'r') as f:
    x = f.read()
with open(b, 'r') as f:
    y = f.read()
with open(c, 'r') as f:
    z = f.read()

f = [(a, x), (b, y), (c, z)]
f.sort(key=lambda i: len(i[1]))

with open(f[2][0], 'w') as f1:
    f1.write(f[0][1])

print(f"{f[2][0]} fayli {f[0][0]} faylning tarkibi bilan almashtirildi.")