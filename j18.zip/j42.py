from os import rename
v="file3"
import os
os.rename("file2",v)
os.rename("file3","file2")