from random import randint
n=randint(1,100)
print("n=",n)
b=list(range(n*2))
for i in b:
    if i%2==1:
        print(i)



