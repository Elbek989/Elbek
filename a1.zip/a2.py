from random import randint
n=randint(1,10)
print("n=",n)
a=[]
d=0
for i in range(n):
    if d<n:
        s=2**d
        a.append(s)
        d+=1

print(a)


