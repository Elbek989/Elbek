from random import randint
n=randint(1,100)
print("n=",n)
a=list(range(n))
a.reverse()
print(a)