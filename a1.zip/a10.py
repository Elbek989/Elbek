from random import randint
n=randint(1,100)
print("n=",n)
a=list(range(n))
b=[]
c=[]
for i in a:
    if i%2==0:
        c.append(i)
    else:
        b.append(i)
b.reverse()
print(b)
print(c)