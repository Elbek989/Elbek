class Person:
    def __init__(self,username,surname,age,phonenumber):
        self.username=username
        self.surname=surname
        self.age=age
        self.phonenumber=phonenumber
        self.card=[]
        self.korzinka=[]

        def add_card(self, object: object):
            self.kartalari.append(object)

        def add_maxsulot(self, object: object):
            self.korzinka.append(object)



class Card:
    def __init__(self,user,number,code,balance,activetime):
        self.number=number
        self.code=code
        self.balance=balance
        self.activetime=activetime



class Supermarket:
    def __init__(self,location,hisobraqam,title):
        self.location=location
        self.hisobraqam=hisobraqam

        self.title=title
        self.mahsulotlar=[]

    def mahsulot_qoshish(self, mahsulot: object):
            self.mahsulotlar.append(mahsulot)
class Mahsulot:
    def __init__(self,title,price,quantity):
        self.title=title
        self.price=price
        self.quantity=quantity
user2 = Person("ali4", "val1", "20", "+998990009931")
card= Card("ali4","220000","0055",100000,"05/28")
user1 = Person("ali5", "vali1", "23", "+998990004311")
card1=Card("ali5","330000","3939",77000,"08/20")
user3 = Person("ali3", "vai1", "30", "+998990009211")
card2 = Card("ali3", "330090", "0000", 700000, "08/10")
user4 = Person("ali1", "val", "20", "+998990009944")
card3 = Card("ali1", "330001", "3039", 177000, "05/20")
user5 = Person("ali2", "vli1", "50", "+998990039911")
card4 = Card("ali2", "330033", "2239", 774000, "08/21")
users=[user1,user2,user3,user4,user5]

def supermarket_manager():
    supermarket=Supermarket("yunusobod",1000,"MAKRO")
    mahsulot=Mahsulot("Olma",25000,100)
    mahsulot1 = Mahsulot("Anor", 35000, 100)
    mahsulot2 = Mahsulot("Olcha", 30000, 100)
    supermarket.mahsulot_qoshish(mahsulot)
    supermarket.mahsulot_qoshish(mahsulot1)
    supermarket.mahsulot_qoshish(mahsulot2)
    user=[user1,user2,user3,user4,user5]
supermarket=Supermarket("yunusobod",1000,"MAKRO")
mahsulot=Mahsulot("Olma",25000,100)
mahsulot1 = Mahsulot("Anor", 35000, 100)
mahsulot2 = Mahsulot("Olcha", 30000, 100)
mevalar=[mahsulot.title,mahsulot1.title,mahsulot2.title]






name=input("Usernameni kiriting:")
for item in users:
    if item.username==name:
        kod=int(input("1.mahsulotlarni kurish:\n2.karzinkani kurish:\n3.karta malumotlarini kurish:\n4.chiqish:"))
        if kod==1:
            a=1
            for i in mevalar:
                print(a,".",i)
                a+=1
                haridlar=int(input("Harid qilmoqchi bulgan mevangizni tartib raqmini kiriting:"))
                kilo=int(input("miqdorini kiriting<<kg da>>:"))
                if haridlar==1:
                    narx=mahsulot.price*kilo
                    tanlov=int(input("haridni  tasdiqlash uchun 1 ni bosing"))
                    if tanlov==1


        if kod==2:




        break