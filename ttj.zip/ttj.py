import re
from random import randint

class Xona:
    def init(self, raqam, holat, sigim, qavat):
        self._raqam = raqam
        self.holat = holat
        self.sigim = sigim
        self.qavat = qavat

    @property
    def raqam(self):
        return self._raqam

    @property
    def holat(self):
        return self._holat

    @property
    def sigim(self):
        return self._sigim

    @property
    def qavat(self):
        return self._qavat

    @holat.setter
    def holat(self, qiymat):
        if qiymat in ["bo'sh", "aktiv"]:
            self._holat = qiymat
        else:
            raise ValueError("Noto‘g‘ri holat kiritildi.")

    @sigim.setter
    def sigim(self, qiymat):
        if qiymat > 0:
            self._sigim = qiymat
        else:
            raise ValueError("Sig‘im 0 dan katta bo‘lishi kerak.")

    @qavat.setter
    def qavat(self, qiymat):
        if 1 <= qiymat <= 5:
            self._qavat = qiymat
        else:
            raise ValueError("Qavat 1 va 5 oralig‘ida bo‘lishi kerak.")

    def repr(self):
        return f"Xona raqami: {self.raqam}, Holati: {self.holat}, Sig‘imi: {self.sigim}, Qavati: {self.qavat}"

class TTJ:
    def init(self, nomi, telefon, manzil, xonalar):
        if not re.match(r"^\+998\d{9}$", telefon):
            raise ValueError("Telefon raqami +998 bilan boshlanib, 9 xonali bo‘lishi kerak.")
        self.nomi = nomi
        self.telefon = telefon
        self.manzil = manzil
        self.xonalar = xonalar

def yarat_xonalar():
    xonalar = []
    for raqam in range(1, 201):
        holat = "bo'sh" if randint(0, 10) == 0 else "aktiv"
        sigim = randint(2, 4)
        qavat = randint(1, 5)
        xona = Xona(raqam, holat, sigim, qavat)
        xonalar.append(xona)
    return xonalar

ttj = TTJ("TTJ", "+998901234567", "Mirzo Ulug‘bek", yarat_xonalar())

print("1 - Bo‘sh xonalarni ko‘rish")
print("2 - Aktiv xonalarni ko‘rish")
print("3 - Barcha xonalarni ko‘rish")
print("4 - Xona raqamiga ko‘ra qidirish (regex)")
print("0 - Chiqish")

tanlov_kiritildi = input("Tanlang (0-4): ")

if not re.match(r"^\d$", tanlov_kiritildi):
    print("Faqat raqam kiritish kerak!")
else:
    tanlov = int(tanlov_kiritildi)

    if tanlov == 0:
        print("Dasturdan chiqildi.")
    elif tanlov == 1:
        for xona in ttj.xonalar:
            if xona.holat == "bo'sh":
                print(xona)
    elif tanlov == 2:
        for xona in ttj.xonalar:
            if xona.holat == "aktiv":
                print(xona)
    elif tanlov == 3:
        for xona in ttj.xonalar:
            print(xona)
    elif tanlov == 4:
        if len(ttj.xonalar) == 0:
            print("Xonalar mavjud emas.")
        else:
            qidiruv = input("Qidiruv uchun xona raqami (regex): ")
            print("Mos kelgan xonalar:")
            for xona in ttj.xonalar:
                if re.search(qidiruv, str(xona.raqam)):
                    print(xona)
    else:
        print("Noto‘g‘ri tanlov.")