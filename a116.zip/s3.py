b=str(input("harf kiriting"))
print(chr(ord(b)-1),chr(ord(b)+1))

