b=str(input("harf kiriting"))
print(ord(b))
