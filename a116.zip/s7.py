s="a,d,f,x,f,v,h"
print(ord(s[0]),ord(s[-1]))
