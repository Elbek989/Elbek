from random import randint
n=randint(1,26)
a=list(range(n))
a.reverse()
s=""
for i in a:
    s+=chr(i+97)

print(s)
