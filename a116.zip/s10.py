s="aedjfnv"
s=s[::-1]
print(s)