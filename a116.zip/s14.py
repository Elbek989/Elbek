s="adfefefW234"
y=0
for i in s:
    if ord(i)>64 and ord(i)<94:
        y+=1
print(y)