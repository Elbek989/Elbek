

a = [1, 1, 1, 4, 4, 44, 6, 6, 7, 0, 0, 0, 0, 0, 1, 1, 1]
b= [a[0]]
c = [1]
count = 0
for i in range(1, len(a)):
    if a[i] == a[i - 1]:
        c[count] += 1
    else:
        c.append(1)
        count += 1
        b.append(a[i])
print(b, c)


