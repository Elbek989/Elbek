from random import randint
N=randint(1,100)
print(N)
s=""
b=str(input("belgi kiriting"))
for i in range(N):
    s+=b
print(s)