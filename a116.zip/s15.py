s="adfefefW234"
y=0
for i in s:
    if ord(i)>96 and ord(i)<123:
        y+=1
print(y)