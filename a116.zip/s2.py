from random import randint
n=randint(32,126)
print("n=",n)
print(chr(n))