s="aedjfnv"
d=""
for i in s:
    d+=i
    d+=" "
print(d)