s="556577"
s=s[::-1]
print(s)