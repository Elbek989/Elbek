s=""
b="a,d,f,r,g,q"
a="1,3,4,5,2,4"
s+=b
s+=a
print(s)