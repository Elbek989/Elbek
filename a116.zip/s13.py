s="adfefefe234"
y=0
for i in s:
    if ord(i)>47 and ord(i)<58:
        y+=1
print(y)